package projects.springboot.blogster.exception;

import org.springframework.http.HttpStatus;

public class BlogAPIException extends RuntimeException{
    private HttpStatus status;
    private String message1;

    public BlogAPIException(HttpStatus status, String message1) {
        this.status = status;
        this.message1 = message1;
    }

    public BlogAPIException(String message, HttpStatus status, String message1) {
        super(message);
        this.status = status;
        this.message1 = message1;
    }
}
