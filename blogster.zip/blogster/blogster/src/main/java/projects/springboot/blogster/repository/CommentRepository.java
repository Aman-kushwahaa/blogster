package projects.springboot.blogster.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import projects.springboot.blogster.entity.Comment;
import projects.springboot.blogster.entity.Post;

//we dont need to annotate with repository because simple jpa repositry implements SImpleJpaRepository
// which is already annoted with repository internally

public interface CommentRepository extends JpaRepository<Comment,Long> {
	List<Comment> findByPostId(Long postId);


}
