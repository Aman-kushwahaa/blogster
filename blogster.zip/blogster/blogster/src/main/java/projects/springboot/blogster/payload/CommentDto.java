package projects.springboot.blogster.payload;

import lombok.Data;
import projects.springboot.blogster.entity.Post;

@Data
public class CommentDto {
    private long id ;
    private String body;
    private String name;
    private String email;

}
