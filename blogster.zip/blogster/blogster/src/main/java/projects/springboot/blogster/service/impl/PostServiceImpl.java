package projects.springboot.blogster.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import projects.springboot.blogster.entity.Comment;
import projects.springboot.blogster.entity.Post;
import projects.springboot.blogster.exception.ResourceNotFoundException;
import projects.springboot.blogster.payload.CommentDto;
import projects.springboot.blogster.payload.PostDto;
import projects.springboot.blogster.payload.PostResponse;
import projects.springboot.blogster.repository.PostRepository;
import projects.springboot.blogster.service.PostService;

import java.awt.print.Pageable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PostServiceImpl implements PostService {

    private PostRepository postRepository;
    private ModelMapper mapper;

    public PostServiceImpl(PostRepository postRepository, ModelMapper mapper) {// if the class is a bean and there is only one constructor than we can omit Autowired annotation
        this.postRepository = postRepository;
        this.mapper=mapper;
    }

    @Override
    public PostDto createPost(PostDto postDto) {
        //convert Dto to entity
        Post post = mapToEntity(postDto);
        Post newPost = postRepository.save(post);

        //convert entity to Dto
        PostDto postResponse = mapToDto(newPost);
        return postResponse;


    }

    @Override
    public PostResponse getAllPosts(int pgNo, int pgSize, String sortBy, String sortDir) {
        //creating pageable instance

        Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name())
                ?Sort
                .by(sortBy)
                .ascending()
                :Sort
                .by(sortBy)
                .descending();
        PageRequest pageable = PageRequest.of(pgNo, pgSize, sort);

        Page<Post> posts = postRepository.findAll(pageable);

        //getContent from page object
        List<Post> listOfPosts = posts.getContent();
        List<PostDto> content = listOfPosts.stream().map(post -> mapToDto(post)).collect(Collectors.toList());


        PostResponse postResponse =new PostResponse();

        //all the get methods are from Page library
        postResponse.setContent(content);
        postResponse.setPageNo(posts.getNumber());
        postResponse.setPageSize(posts.getSize());
        postResponse.setTotalPages(posts.getTotalPages());
        postResponse.setTotalElements(posts.getTotalElements());
        postResponse.setLast(posts.isLast());

        return postResponse;
    }

    @Override
    public PostDto getPostById(Long id) {

        Post post = postRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Post", "id", id));
        PostDto postDto = mapToDto(post);
        return postDto;
    }

    @Override
    public PostDto updatePosts(PostDto postDto, Long id) {
        Post post = postRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Post", "id", id));
        post.setTitle(postDto.getTitle());
        post.setDescription(postDto.getDescription());
        post.setContent(postDto.getContent());

        Post updatedPost = postRepository.save(post);

        PostDto updatePostDto = mapToDto(updatedPost);


        return updatePostDto;
    }

    @Override
    public void deletePost(Long id) {
        Post post = postRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Post", "id", id));
        postRepository.delete(post);

    }


    //method to create entity into Dto
    private PostDto mapToDto(Post post) {


        PostDto postDto = this.mapper.map(post,PostDto.class);

//        PostDto postDto = new PostDto();
//        postDto.setId(post.getId());
//        postDto.setDescription(post.getDescription());
//        postDto.setContent(post.getContent());
//        postDto.setTitle(post.getTitle());

        return postDto;
    }

    //method to convert Dto into entity
    private Post mapToEntity(PostDto postDto) {
        Post post = this.mapper.map(postDto, Post.class);


//        Post post = new Post();
//        post.setTitle(postDto.getTitle());
//        post.setContent(postDto.getContent());
//        post.setDescription(postDto.getDescription());


        return post;

    }
}
