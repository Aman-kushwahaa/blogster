package projects.springboot.blogster.service;

import projects.springboot.blogster.payload.PostDto;
import projects.springboot.blogster.payload.PostResponse;

import java.util.List;

public interface PostService {

    PostDto createPost(PostDto postDto);
    PostResponse getAllPosts(int pgNo, int pgSize, String sortBy, String sortDir);

    PostDto getPostById(Long id);

    PostDto updatePosts(PostDto postDto, Long id);

    void deletePost(Long id);

}
