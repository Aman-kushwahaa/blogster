package projects.springboot.blogster.repository;

import jakarta.persistence.Id;
import org.springframework.data.jpa.repository.JpaRepository;
import projects.springboot.blogster.entity.Post;

//we dont need to annotate with repository because simple jpa repositry is already annoted with repository internally

public interface PostRepository extends JpaRepository<Post, Long> {
    //spring data jpa provides all implements all methods.
    //    it internally extends crud repository
}
