package projects.springboot.blogster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogsterApplicationTests {

	@Test
	void contextLoads() {
	}

}
